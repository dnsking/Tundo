package com.musicg.math.quicksort;

public abstract class QuickSort{
	public abstract int[] getSortIndexes();
}