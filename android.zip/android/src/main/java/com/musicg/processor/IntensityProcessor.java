package com.musicg.processor;

public interface IntensityProcessor{
	public void execute();
	public double[][] getIntensities();
}