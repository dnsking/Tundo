package transearly.app.ltd.com.transearly;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.github.angads25.toggle.LabeledSwitch;
import com.github.angads25.toggle.interfaces.OnToggledListener;
import com.google.gson.Gson;
import com.ramotion.directselect.DSDefaultPickerBox;
import com.ramotion.directselect.DSListView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;

import transearly.app.ltd.com.transearly.data.TranslateResponse;
import transearly.app.ltd.com.transearly.utils.FileUtils;
import transearly.app.ltd.com.transearly.utils.SystemUtils;
import transearly.app.ltd.com.transearly.views.CustomDSDefaultPickerBox;

public class MainActivity extends AppCompatActivity {
    private MediaProjectionManager mediaProjectionManager;
    private LabeledSwitch switchBtn;
    private CustomDSDefaultPickerBox picker_box;
    private DSListView ds_picker;
    private String[] supportedLans = new String[]{"en","fr","de","it","ja","pt","ru","es","tr","zh","cs","id","sv"
    ,"pl","nl","da","fi"};
    private ArrayList<String> supportedLansList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        switchBtn = findViewById(R.id.switchBtn);
        picker_box = findViewById(R.id.picker_box);
        ds_picker = findViewById(R.id.ds_picker);

        picker_box.setEnabled(false);
        supportedLansList = new ArrayList<String>(Arrays.asList(supportedLans)) ;

        App.Log("device lan "+Locale.getDefault().getLanguage()
                +" saved lan "+App.Settings.GetString(this,App.Settings.Language));
        if(!App.Settings.GetBoolean(this,
                App.Settings.IsActivated)){
           String deviceLan = Locale.getDefault().getLanguage();
           if(supportedLansList.contains(deviceLan.toLowerCase())){
               App.Settings.SetString(this,App.Settings.Language,deviceLan.toLowerCase());

               ds_picker.setSelectedIndex(supportedLansList.indexOf(deviceLan));
           }
           else{

               App.Settings.SetString(this,App.Settings.Language,supportedLans[0]);
               ds_picker.setSelectedIndex(supportedLansList.indexOf(supportedLans[0]));
           }
        }
        else{

            ds_picker.setSelectedIndex( supportedLansList.indexOf(App.Settings.GetString(this,App.Settings.Language)));
        }
        picker_box.setOnSelectLanguageListener(new CustomDSDefaultPickerBox.OnSelectLanguageListener() {
            @Override
            public void languageSelected(String lan,int index) {
                App.Settings.SetString(MainActivity.this,App.Settings.Language,
                        supportedLans[index]);
            }
        });

        switchBtn.setOn(App.Settings.GetBoolean(this,
                App.Settings.IsActivated) && App.Settings.GetBoolean(this,App.Settings.HasPermissions));

        switchBtn.setOnToggledListener(new OnToggledListener() {

            @Override
            public void onSwitched(LabeledSwitch labeledSwitch, boolean isOn) {
                App.Settings.SetBoolean(MainActivity.this,App.Settings.IsActivated,isOn);

                picker_box.setEnabled(isOn);
                if(App.Settings.GetBoolean(MainActivity.this,App.Settings.HasPermissions)){

                    picker_box.setEnabled(true);
                    startDoubleTapObserver();
                }
                else{

                    mediaProjectionManager = (MediaProjectionManager)MainActivity.this.getSystemService(MEDIA_PROJECTION_SERVICE);
                    startActivityForResult(mediaProjectionManager.createScreenCaptureIntent(), 1);}
                    if(!isOn){

                        Intent intent= new Intent();
                        intent.setAction( App.TurnedOff);
                        sendBroadcast(intent);
                    }
                    else{

                        Intent intent= new Intent();
                        intent.setAction( App.TurnedOn);
                        sendBroadcast(intent);
                    }
            }

        });
        if(App.Settings.GetBoolean(this,
                App.Settings.IsActivated) && App.Settings.GetBoolean(this,App.Settings.HasPermissions)){

            mediaProjectionManager = (MediaProjectionManager)MainActivity.this.getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mediaProjectionManager.createScreenCaptureIntent(), 1);
        //    startDoubleTapObserver();
            picker_box.setEnabled(true);
        }
    }
    private void startDoubleTapObserver(){

        App.Settings.SetBoolean(this,App.Settings.HasPermissions,true);
        Intent intent = new Intent(this,DoubleTabObserverService.class);
        startService(intent);

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Intent intent = new Intent(App.Permission.Receiver);
        Bundle mBundle = new Bundle();
        if (1 == requestCode) {
            if (Activity.RESULT_OK == resultCode) {
                App.setScreenshotPermission((Intent) data.clone());
                mBundle.putBoolean(App.Permission.PermissionGiven,true);
                intent.putExtras(mBundle);
                sendBroadcast(intent);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkDrawOverlayPermission();
                }
            }
            else if (Activity.RESULT_CANCELED == resultCode) {
                App.setScreenshotPermission(null);

                mBundle.putBoolean(App.Permission.PermissionGiven,false);
                intent.putExtras(mBundle);
                sendBroadcast(intent);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    checkDrawOverlayPermission();
                }

            }}
            else{
            App.Settings.SetBoolean(this,App.Settings.HasPermissions,true);

            picker_box.setEnabled(true);
            startDoubleTapObserver();
        }
    }

    public final static int REQUEST_CODE_OVERLLAY = 35;

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void checkDrawOverlayPermission() {
        Log.v("App", "Package Name: " + getApplicationContext().getPackageName());

        // check if we already  have permission to draw over other apps
        if (!Settings.canDrawOverlays(this)) {
            Log.v("App", "Requesting Permission" + Settings.canDrawOverlays(this));
            // if not construct intent to request permission
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getApplicationContext().getPackageName()));
            startActivityForResult(intent, REQUEST_CODE_OVERLLAY);
        } else {
            startDoubleTapObserver();
        }
    }

}
