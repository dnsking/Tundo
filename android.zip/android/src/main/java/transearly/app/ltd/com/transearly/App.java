package transearly.app.ltd.com.transearly;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;

import com.okta.appauth.android.OktaAppAuth;

import net.openid.appauth.AuthState;
import net.openid.appauth.AuthorizationException;

import java.util.Calendar;

/**
 * Created by pc on 11/6/2018.
 */

public class App extends Application {
    private static Intent screenshotPermission = null;
    public static Context context;
    public static boolean IsDebug = true;
    public static final String Path = "Path";
    private static final String TAG = "Translate";
    //  public static final String ServerUrl = "http://192.168.42.43:5000";


    public static String issuer="https://dev-583451.okta.com/oauth2/default";
    public static String audience="api://default";
    public static String client_ids="0oae72yu4L4ydW7lN356";

    public static final String ServerUrl = "http://192.168.43.6:5000";
    public static final String GeneratePublicS3Url ="https://ew7hihnguf.execute-api.eu-west-1.amazonaws.com/TundoStage/urlgen";

    public static final String GeneratePublicS3UrlmethodArn="arn:aws:execute-api:eu-west-1:424961117306:ew7hihnguf/*/PUT/urlgen";
    public static final String TonduTranslationS3Url ="https://ew7hihnguf.execute-api.eu-west-1.amazonaws.com/TundoStage/tundo";

    public static final String TranslationActivityCancledIntentFilter = "TranslationActivityCancled";
    public static final String TranslationActivityIsTranslatingIntentFilter = "TranslationActivityIsTranslatingIntentFilter";
    public static final String TranslationActivityHasFailedIntentFilter = "TranslationActivityHasFailedIntentFilter";
    public static final String TranslationActivityIsShowingResultsIntentFilter = "TranslationActivityIsShowingResultsIntentFilter";

    public static final String TurnedOff = "TurnedOff";
    public static final String TurnedOn = "TurnedOn";
    public static int StatusBarHeight =0;
    public static void Log(String msg){
        if(App.IsDebug){
            int maxLogSize = 1000;
            if(msg.length()>maxLogSize)
                for(int i = 0; i <= msg.length() / maxLogSize; i++) {
                    int start = i * maxLogSize;
                    int end = (i+1) * maxLogSize;
                    end = end > msg.length() ? msg.length() : end;
                    Log.i(TAG, msg.substring(start, end));
                }
            else
                Log.i(TAG, msg);
        }
    }

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub

        super.onCreate();
        this.context = getApplicationContext();
        StatusBarHeight =StatusBarHeight(this);


    }
    protected static void getScreenshotPermission() {
        Intent intent = new Intent(App.Permission.Receiver);
        Bundle mBundle = new Bundle();
        try {
            if (hasScreenshotPermission()) {

                mBundle.putBoolean(App.Permission.PermissionGiven,true);
                intent.putExtras(mBundle);
                context.sendBroadcast(intent);
            } else {
                openScreenshotPermissionRequester();
            }
        } catch (final RuntimeException ignored) {
            openScreenshotPermissionRequester();
            mBundle.putBoolean(App.Permission.PermissionGiven,false);
            intent.putExtras(mBundle);
            context.sendBroadcast(intent);
        }
    }

    protected static void openScreenshotPermissionRequester(){
        final Intent intent = new Intent(context, AcquireScreenshotPermissionActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }



    protected static void setScreenshotPermission(final Intent permissionIntent) {
        screenshotPermission = permissionIntent;
    }
    protected static boolean hasScreenshotPermission(){
        return screenshotPermission!=null;
    }
    protected static Intent getScreenshotPermissionIntent(){
        return (Intent) screenshotPermission.clone();
    }


    public static void setDefaultLanguage(String lan){
       /* SharedPreferences settings =context. getSharedPreferences(
                App.Prefs, 0);
        SharedPreferences.Editor editor= settings.edit();
        editor.putBoolean(App.Communication.LoopSetting, loop);
        editor.apply();
        editor.commit();*/
    }


    public static class Permission{
        public final static String Receiver = "21";
        public final static String PermissionGiven = "PermissionGiven";
    }
    public static AuthState ReadAuthState(Context mContext){
        SharedPreferences authPrefs = mContext.getSharedPreferences("OktaAppAuthState",Context.MODE_PRIVATE);
        String stateJson = authPrefs.getString("state","");
        App.Log("token stateJson "+stateJson);
        if(!stateJson.isEmpty()){
            try{
                return AuthState.jsonDeserialize(stateJson);
            }
            catch (Exception e){
                return  null;
            }
        }
        else{
            return  null;}

    }
    public  interface ReadTokenListener{
        void TokenRead(String token);
    }
    public static void ReadToken(final Context mContext,final ReadTokenListener mReadTokenListener){

            OktaAppAuth mOktaAuth = OktaAppAuth.getInstance(mContext);

        Calendar c =Calendar.getInstance();

        if(c.getTimeInMillis()> mOktaAuth.getAccessTokenExpirationTime()){

            mOktaAuth.refreshAccessToken(new OktaAppAuth.OktaAuthListener() {
                @Override
                public void onSuccess() {

                    AuthState mAuthState = ReadAuthState( mContext);
                    mReadTokenListener.TokenRead(mAuthState.getAccessToken());

                }

                @Override
                public void onTokenFailure(@NonNull AuthorizationException ex) {
                }
            });
        }
        else{

            AuthState mAuthState = ReadAuthState( mContext);
            mReadTokenListener.TokenRead(mAuthState.getAccessToken());
        }
    }


    public static class Settings{
        public final static String IsSetup = "IsSetup";

        public final static String IsActivated = "IsActivated";
        public final static String Settings = "Settings";

        public final static String HasPermissions = "HasPermissions";

        public final static String Language = "Language";

        public final static String isRunning = "isRunning";
        public final static String isTranslation = "isTranslation";

        public static SharedPreferences hasSetting(Context mContext){
            SharedPreferences mySharedPreferences = mContext.getSharedPreferences(Settings,
                    Activity.MODE_PRIVATE);
            return mySharedPreferences;
        }
        public static boolean GetBoolean(Context mContext,String name){
            return   hasSetting( mContext).getBoolean(name,false);
        }
        public static void SetBoolean(Context mContext,String name,boolean value){
            SharedPreferences.Editor editor = hasSetting( mContext).edit();
            editor.putBoolean(name,value);
            editor.apply();
        }

        public static String GetString(Context mContext,String name){
            return   hasSetting( mContext).getString(name,null);
        }
        public static void SetString(Context mContext,String name,String value){
            SharedPreferences.Editor editor = hasSetting( mContext).edit();
            editor.putString(name,value);
            editor.apply();
        }
    }
    public static int StatusBarHeight(Context mContext){
        int result = 0;
        int resid = mContext.getResources().getIdentifier("status_bar_height","dimen","android");
        if(resid>0){
            result = mContext.getResources().getDimensionPixelSize(resid);
        }
        return result;
    }
}
