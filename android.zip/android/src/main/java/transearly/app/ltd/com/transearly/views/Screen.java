/*
 * Copyright 2016 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package transearly.app.ltd.com.transearly.views;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import java.util.HashMap;
import java.util.Map;

import transearly.app.ltd.com.transearly.views.*;
import transearly.app.ltd.com.transearly.views.ContentDisplay;
import transearly.app.ltd.com.transearly.views.ExitView;
import transearly.app.ltd.com.transearly.views.FloatingTab;
import transearly.app.ltd.com.transearly.views.HoverMenu;

import static android.view.View.GONE;

/**
 * The visual area occupied by a {@link transearly.app.ltd.com.transearly.views.HoverView}. A {@code Screen} acts as a factory for the
 * visual elements used within a {@code HoverView}.
 */
class Screen {

    private static final String TAG = "Screen";

    private ViewGroup mContainer;
    private transearly.app.ltd.com.transearly.views.ContentDisplay mContentDisplay;
    private transearly.app.ltd.com.transearly.views.ExitView mExitView;
    private ShadeView mShadeView;
    private Map<String, transearly.app.ltd.com.transearly.views.FloatingTab> mTabs = new HashMap<>();
    private boolean mIsDebugMode = false;

    Screen(@NonNull ViewGroup hoverMenuContainer) {
        mContainer = hoverMenuContainer;

        mShadeView = new ShadeView(mContainer.getContext());
        mContainer.addView(mShadeView, new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        mShadeView.hideImmediate();

        mExitView = new transearly.app.ltd.com.transearly.views.ExitView(mContainer.getContext());
        mContainer.addView(mExitView, new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        mExitView.setVisibility(GONE);

        mContentDisplay = new transearly.app.ltd.com.transearly.views.ContentDisplay(mContainer.getContext());
        mContainer.addView(mContentDisplay);
        mContentDisplay.setVisibility(GONE);
    }

    public void enableDrugMode(boolean debugMode) {
        mIsDebugMode = debugMode;

        mContentDisplay.enableDebugMode(debugMode);
        for (transearly.app.ltd.com.transearly.views.FloatingTab tab : mTabs.values()) {
            tab.enableDebugMode(debugMode);
        }
    }

    public int getWidth() {
        return mContainer.getWidth();
    }

    public int getHeight() {
        return mContainer.getHeight();
    }

    @NonNull
    public transearly.app.ltd.com.transearly.views.FloatingTab createChainedTab(@NonNull transearly.app.ltd.com.transearly.views.HoverMenu.SectionId sectionId, @NonNull View tabView) {
        String tabId = sectionId.toString();
        return createChainedTab(tabId, tabView);
    }

    @NonNull
    public transearly.app.ltd.com.transearly.views.FloatingTab createChainedTab(@NonNull String tabId, @NonNull View tabView) {
        Log.d(TAG, "Existing tabs...");
        for (String existingTabId : mTabs.keySet()) {
            Log.d(TAG, existingTabId);
        }
        if (mTabs.containsKey(tabId)) {
            return mTabs.get(tabId);
        } else {
            Log.d(TAG, "Creating new tab with ID: " + tabId);
            transearly.app.ltd.com.transearly.views.FloatingTab chainedTab = new transearly.app.ltd.com.transearly.views.FloatingTab(mContainer.getContext(), tabId);
            chainedTab.setTabView(tabView);
            chainedTab.enableDebugMode(mIsDebugMode);
            mContainer.addView(chainedTab);
            mTabs.put(tabId, chainedTab);
            return chainedTab;
        }
    }

    @Nullable
    public transearly.app.ltd.com.transearly.views.FloatingTab getChainedTab(@Nullable HoverMenu.SectionId sectionId) {
        String tabId = null != sectionId ? sectionId.toString() : null;
        return getChainedTab(tabId);
    }

    @Nullable
    public transearly.app.ltd.com.transearly.views.FloatingTab getChainedTab(@Nullable String tabId) {
        return mTabs.get(tabId);
    }

    public void destroyChainedTab(@NonNull transearly.app.ltd.com.transearly.views.FloatingTab chainedTab) {
        mTabs.remove(chainedTab.getTabId());
        chainedTab.setTabView(null);
        mContainer.removeView(chainedTab);
    }

    public transearly.app.ltd.com.transearly.views.ContentDisplay getContentDisplay() {
        return mContentDisplay;
    }

    public transearly.app.ltd.com.transearly.views.ExitView getExitView() {
        return mExitView;
    }

    public ShadeView getShadeView() {
        return mShadeView;
    }
}
