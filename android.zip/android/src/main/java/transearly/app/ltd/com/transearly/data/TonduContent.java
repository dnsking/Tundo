package transearly.app.ltd.com.transearly.data;

import transearly.app.ltd.com.transearly.App;

/**
 * Created by pc on 3/29/2019.
 */

public class TonduContent {
    private String authorizationToken;
    private String issuer = App.issuer;
    private String audience = App.audience;
    private String client_ids = App.client_ids;
    private String methodArn;

    public TonduContent(){}
    public TonduContent(String authorizationToken,String methodArn){
        this.authorizationToken = authorizationToken;
        this.methodArn = methodArn;
    }

    public String getAuthorizationToken() {
        return authorizationToken;
    }

    public void setAuthorizationToken(String authorizationToken) {
        this.authorizationToken = authorizationToken;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public String getClient_ids() {
        return client_ids;
    }

    public void setClient_ids(String client_ids) {
        this.client_ids = client_ids;
    }

    public String getMethodArn() {
        return methodArn;
    }

    public void setMethodArn(String methodArn) {
        this.methodArn = methodArn;
    }
}
