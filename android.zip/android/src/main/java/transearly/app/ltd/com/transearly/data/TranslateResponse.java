package transearly.app.ltd.com.transearly.data;

public class TranslateResponse {

   private String DetectedText;
   private String TranslatedText;
   private Geometry Geometry;

   public String getDetectedText() {
      return DetectedText;
   }

   public void setDetectedText(String detectedText) {
      DetectedText = detectedText;
   }

   public String getTranslatedText() {
      return TranslatedText;
   }

   public void setTranslatedText(String translatedText) {
      TranslatedText = translatedText;
   }

   public transearly.app.ltd.com.transearly.data.Geometry getGeometry() {
      return Geometry;
   }

   public void setGeometry(transearly.app.ltd.com.transearly.data.Geometry geometry) {
      Geometry = geometry;
   }
}
