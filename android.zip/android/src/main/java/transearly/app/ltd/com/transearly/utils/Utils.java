package transearly.app.ltd.com.transearly.utils;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import transearly.app.ltd.com.transearly.App;


public class Utils {
	public static long minsTomillis(long mins){
		return mins*60*1000;
	}
	public static long millisTomins(long millis){
		return millis/(1000*60);
	}
	public static long secsTomillis(long secs){
		return secs*1000;
	}
	public static int convertDpToPixelInt(Context context, float dp) {

		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		int px = (int) (dp * (metrics.densityDpi / 160f));
		return px;
	}
	public static boolean hasLollipop(){
		return Build.VERSION.SDK_INT>=21;
	}
	public static void setStatusBarColor(final Activity target,int color){
		if(hasLollipop()){
				target.getWindow().setStatusBarColor(color);
		}

	}
	public static float spToPixels(Context context,float sp){
		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		float px = sp * (metrics.scaledDensity );
		return px;
	}
	
	public static float convertDpToPixel(Context context, float dp) {

		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		float px = (float) (dp * (metrics.densityDpi / 160f));
		return px;
	}

	public static void saveBytes(byte[] bytes, String destinationFile) throws IOException {
		OutputStream os = new FileOutputStream(destinationFile);
		os.write(bytes, 0, bytes.length);
		os.close();
	}
	public static void SaveBitmap(Bitmap bm,String path) throws IOException {
        OutputStream os = new FileOutputStream(path);
        bm.compress(Bitmap.CompressFormat.JPEG,100,os);

        os.close();
    }
    public static int KeepNumbers(String str){
		return Integer.parseInt(str.replaceAll("[^\\d.]", ""));
	}

    public static String getCacheThumPath(Context activity){
        File parent = new File(activity.getExternalCacheDir()+"/"+"thumbs");
        if(!parent.exists()){
            parent.mkdirs();
        }
        return parent.getAbsolutePath();
    }

    public static String getTempPath(Context activity){
        File parent = new File(activity.getExternalCacheDir()+"/"+"temp");
        if(!parent.exists()){
            parent.mkdirs();
        }
        return parent.getAbsolutePath();
    }

	public static String getCachePath(Context activity){
		File parent = activity.getExternalCacheDir();
		if(!parent.exists()){
			parent.mkdirs();
		}
		return parent.getAbsolutePath();
	}
    public static Bitmap drawableToBitmap (Drawable drawable) {
        Bitmap bitmap = null;

        if (drawable instanceof BitmapDrawable) {
            BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
            if(bitmapDrawable.getBitmap() != null) {
                return bitmapDrawable.getBitmap();
            }
        }

        if(drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); // Single color bitmap will be created of 1x1 pixel
        } else {
            bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }
    public static void moveAssetToStorageDir(Context context,String path){
        File file = context.getExternalCacheDir();
        String rootPath = file.getPath() + "/" + path;
        try{
            String [] paths = context.getAssets().list(path);
            for(int i=0; i<paths.length; i++){
				App.Log("moveAssetToStorageDir path "+paths[i]);
				if(paths[i].indexOf(".")==-1){
                    File dir = new File(rootPath + paths[i]);
                    dir.mkdir();
                    moveAssetToStorageDir(context,paths[i]);
                }else {
                    try{

                        File dest = null;
                        InputStream in = null;
                        if(path.length() == 0) {
                            dest = new File(rootPath + paths[i]);
                            in = context.getAssets().open(paths[i]);
                        }else{
                            dest = new File(rootPath + "/" + paths[i]);
                            in = context.getAssets().open(path + "/" + paths[i]);
                        }
                        dest.createNewFile();
                        FileOutputStream out = new FileOutputStream(dest);
                        byte [] buff = new byte[in.available()];
                        in.read(buff);
                        out.write(buff);
                        out.close();
                        in.close();
                    }
                    catch (Exception e){}
                }
            }
        }catch (Exception exp){
            exp.printStackTrace();
        }
    }
	public static void CopyAssets(Context context) {
		AssetManager assetManager =context. getAssets();
		String[] files = null;
		try {
			files = assetManager.list("");
		} catch (IOException e) {
			Log.e("tag", "Failed to get asset file list.", e);
		}
		if (files != null)
			for (String filename : files) {
			InputStream in = null;
			OutputStream out = null;
			try {
				in = assetManager.open(filename);
				File outFile = new File(context.getExternalCacheDir(), filename);
				out = new FileOutputStream(outFile);
				CopyFile(in, out);
			} catch(IOException e) {
				Log.e("tag", "Failed to copy asset file: " + filename, e);
			}
			finally {
				if (in != null) {
					try {
						in.close();
					} catch (IOException e) {
						// NOOP
					}
				}
				if (out != null) {
					try {
						out.close();
					} catch (IOException e) {
						// NOOP
					}
				}
			}
		}
	}
	public static void CopyFile(InputStream in, OutputStream out) throws IOException {
		byte[] buffer = new byte[1024];
		int read;
		while((read = in.read(buffer)) != -1){
			out.write(buffer, 0, read);
		}
	}
}
