package transearly.app.ltd.com.transearly.data;

import transearly.app.ltd.com.transearly.App;

/**
 * Created by pc on 3/29/2019.
 */

public class S3UrlRequest extends TonduContent {

    private String keyName;
    public S3UrlRequest(){}
    public S3UrlRequest(String authorizationToken,String keyName){
        super(authorizationToken, App.GeneratePublicS3UrlmethodArn);
        this.keyName = keyName;
    }

    public String getKeyName() {
        return keyName;
    }

    public void setKeyName(String keyName) {
        this.keyName = keyName;
    }
}
