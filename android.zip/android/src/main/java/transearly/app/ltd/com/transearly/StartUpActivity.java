package transearly.app.ltd.com.transearly;

import android.app.PendingIntent;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.okta.appauth.android.OktaAppAuth;

public class StartUpActivity extends AppCompatActivity {

    private Button mGetstartBtn;
    private OktaAppAuth mOktaAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mOktaAuth = OktaAppAuth.getInstance(this);

        if(App.Settings.GetBoolean(this,App.Settings.IsSetup)){

            if(mOktaAuth.isUserLoggedIn()){
                Intent intent = new Intent(this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            }
            else{

                Intent intent = new Intent(this,LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            }
        }
        setContentView(R.layout.activity_start_up);
        mGetstartBtn = findViewById(R.id.getstartBtn);
        mGetstartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSuccess();
            }
        });
    }

    public void onSuccess() {
        // Handle a successful initialization (e.g. display login button)
        App.Settings.SetBoolean(this,App.Settings.IsSetup,true);
        if(mOktaAuth.isUserLoggedIn()){
            Intent intent = new Intent(this,MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            finish();
        }
        else{

            Intent intent = new Intent(this,LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            finish();
        }
    }
}
