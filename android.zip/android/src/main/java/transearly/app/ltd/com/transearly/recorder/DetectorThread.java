package transearly.app.ltd.com.transearly.recorder;

import android.content.Context;

import com.musicg.fingerprint.FingerprintSimilarity;
import com.musicg.wave.WaveHeader;

import java.io.FileNotFoundException;
import java.io.IOException;

import transearly.app.ltd.com.transearly.App;


/**
 * Created by pc on 7/20/2018.
 */

public class DetectorThread extends Thread {
    private volatile Thread _thread;
    private RecorderThread mRecorderThread;
    private AudioFingerPrinter mAudioFingerPrinter;
    private Context mContext;

    private KnockApi knockApi;
    private long lastTapTime;
    private final long maxTapDif = 2500;
    private final long minTapDif = 150;
    private DoubleTapListener mDoubleTapListener;
    public interface DoubleTapListener{
        void onDoubleTapped();
    }
    public DetectorThread(Context mContext,DoubleTapListener mDoubleTapListener){
        this.mContext = mContext;
        this.mDoubleTapListener = mDoubleTapListener;
    }

    public void startDetection() {
        init();
        _thread = new Thread(this);
        _thread.start();


    }
    private void init(){

        mRecorderThread = new RecorderThread();
        mRecorderThread.start();

        try {
            mAudioFingerPrinter = new AudioFingerPrinter(mContext,mRecorderThread.getAudioRecord());
        } catch (IOException e) {
            e.printStackTrace();
        }


        WaveHeader waveHeader = new WaveHeader();
        waveHeader.setChannels(1);
        waveHeader.setBitsPerSample(16);
        waveHeader.setSampleRate(mRecorderThread.getAudioRecord().getSampleRate());
        knockApi = new KnockApi(waveHeader);
    }

    public void stopDetection(){
        if(mRecorderThread!=null)
        mRecorderThread.stopRecording();
        _thread = null;
    }
    @Override
    public void run() {

        App.Log("startRecording ");
        //mRecorderThread.startRecording();

            byte[]   buffer;
            Thread thisThread = Thread.currentThread();
            while (_thread == thisThread) {
                try {
               buffer = mRecorderThread.getFrameBytes();
                if(buffer!=null){
                    /*
                    FingerprintSimilarity mFingerprintSimilarity = mAudioFingerPrinter.getSimilarities(buffer);
                    App.Log("FingerprintSimilarity Score : "+mFingerprintSimilarity.getScore()+"" +
                            "similarity : "+mFingerprintSimilarity.getSimilarity());*/

                    long time = System.currentTimeMillis();
                    boolean isKnock = knockApi.isKnock(buffer);
                    double freq =knockApi.getRobustFreq();
                    int zrcValue=knockApi.getZcrValue();
                    if(isKnock){

                        App.Log( "isKnock "+isKnock+" freq "+freq+" zrcValue "+zrcValue);
                        if((time-lastTapTime)<=maxTapDif &(time-lastTapTime)>=minTapDif ){

                            if(mDoubleTapListener!=null)
                                mDoubleTapListener.onDoubleTapped();
                            lastTapTime = 0;
                        }
                        else{

                            lastTapTime = time;
                        }
                    }


                }
                }
            catch (Exception e){ e.printStackTrace();
                }
            }
    }
}
