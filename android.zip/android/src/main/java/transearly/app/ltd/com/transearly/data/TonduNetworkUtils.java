package transearly.app.ltd.com.transearly.data;

import android.graphics.Bitmap;
import android.util.Log;

import com.google.gson.Gson;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringEscapeUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import transearly.app.ltd.com.transearly.App;

/**
 * Created by pc on 3/29/2019.
 */


public class TonduNetworkUtils {
    public static TonduS3UrlReponse RequestS3Url(String token,String s3key) throws IOException {

        App.Log("startTranslation RequestS3Url");
        S3UrlRequest mS3UrlRequest = new S3UrlRequest(token,s3key);
        Gson gson = new Gson();
        String json = gson.toJson(mS3UrlRequest);
      //  App.Log("test RequestS3Url "+json);
        OkHttpClient client =  new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
        Request request = new Request.Builder()
                .addHeader("Authorization",token)
                .url(App.GeneratePublicS3Url).put(RequestBody.create(MediaType.parse("application/json; charset=utf-8"), json))
                .build();
        Response response = client.newCall(request).execute();
        TonduS3UrlReponse mTonduS3UrlReponse = new Gson().fromJson(response.body().string(),TonduS3UrlReponse.class);
        App.Log("startTranslation RequestS3Url end");
        return mTonduS3UrlReponse;

    }

    public static TonduResponse Translate(String token,String path,String lan)  throws IOException{

        Calendar c = Calendar.getInstance();

        String s3key =c.getTimeInMillis()+"-"+org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(16);
        UploadImage(  RequestS3Url( token, s3key),
                 path, token);
       return ImageTranslation(s3key , lan, token);
    }
    public static String UploadImage(TonduS3UrlReponse mTonduS3UrlReponse,
                                                 String path,String token) throws IOException {

        App.Log("startTranslation UploadImage length "+
                FileUtils.readFileToByteArray(new File(path)).length);
        OkHttpClient client =  new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(300, TimeUnit.SECONDS).readTimeout(300, TimeUnit.SECONDS).build();
        Request request = new Request.Builder()
                .url(mTonduS3UrlReponse.getBody().replaceAll("^\"|\"$",""))
                .put(RequestBody.create(MediaType.parse("image/png"),

                        FileUtils.readFileToByteArray(new File(path))))
                .build();
        Response response = client.newCall(request).execute();
String responseString = response.body().string();
        App.Log("startTranslation UploadImage end "+responseString);
        return responseString;

    }
    public static TonduResponse ImageTranslation(String key,String lan,String token) throws IOException {

        App.Log("startTranslation TonduResponse");
        TonduUrlRequest mTonduUrlRequest = new TonduUrlRequest( token, key, lan);
        Gson gson = new Gson();
        String json = gson.toJson(mTonduUrlRequest);
        //  App.Log("test RequestS3Url "+json);
        OkHttpClient client =  new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
        Request request = new Request.Builder()
                .addHeader("Authorization",token)
                .url(App.TonduTranslationS3Url).put(RequestBody.create(MediaType.parse("application/json; charset=utf-8"), json))
                .build();
        Response response = client.newCall(request).execute();
        String responseString = response.body().string();
        responseString= StringEscapeUtils.unescapeJava(responseString.substring(1,responseString.length()-1));

        App.Log("startTranslation TonduResponse end "+responseString);
        TonduResponse mTonduResponse =new TonduResponse();
        mTonduResponse.setBody(
                new Gson().fromJson(responseString,TonduText[].class));

        App.Log("startTranslation TonduResponse end");
        return mTonduResponse;
    }
}
