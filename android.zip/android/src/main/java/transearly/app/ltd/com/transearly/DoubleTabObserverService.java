package transearly.app.ltd.com.transearly;

import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.OrientationEventListener;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.mikepenz.fontawesome_typeface_library.FontAwesome;
import com.mikepenz.google_material_typeface_library.GoogleMaterial;
import com.mikepenz.iconics.IconicsDrawable;
import com.mikepenz.iconics.context.IconicsContextWrapper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import transearly.app.ltd.com.transearly.utils.Utils;
import transearly.app.ltd.com.transearly.utils.ViewUtils;
import transearly.app.ltd.com.transearly.views.Content;
import transearly.app.ltd.com.transearly.views.HoverMenu;
import transearly.app.ltd.com.transearly.views.HoverView;
import transearly.app.ltd.com.transearly.views.HoverViewStateCollapsed;
import transearly.app.ltd.com.transearly.views.window.HoverMenuService;
import transearly.app.ltd.com.transearly.recorder.DetectorThread;
import transearly.app.ltd.com.transearly.utils.FileUtils;
import transearly.app.ltd.com.transearly.utils.SystemUtils;

public class DoubleTabObserverService extends HoverMenuService implements DetectorThread.DoubleTapListener {

    private DetectorThread mDetectorThread;
    private static final int REQUEST_CODE = 100;
    private static String STORE_DIRECTORY;
    private static int IMAGES_PRODUCED;
    private static final String SCREENCAP_NAME = "screencap";
    private static final int VIRTUAL_DISPLAY_FLAGS = DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY | DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC;
    private static MediaProjection sMediaProjection;

    private MediaProjectionManager mProjectionManager;
    private ImageReader mImageReader;
    private Handler mHandler;
    private Display mDisplay;
    private VirtualDisplay mVirtualDisplay;
    private int mDensity;
    private int mWidth;
    private int mHeight;
    private int mRotation;
    private OrientationChangeCallback mOrientationChangeCallback;

    private final long listenerTime = 20000;
    private ScreenshotPermissionReceiver mScreenshotPermissionReceiver;
    public DoubleTabObserverService() {
    }
    @Override
    protected void attachBaseContext(Context newBase) {
        //GoogleMaterial.Icon.gmd_video_call
        //  com.mikepenz.fontawesome_typeface_library.FontAwesome.Icon.use
        super.attachBaseContext(IconicsContextWrapper.wrap(newBase));
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
   /* @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // TODO Auto-generated method stub
         mScreenshotPermissionReceiver = new ScreenshotPermissionReceiver();

        registerReceiver(new TranslationActivityCancledBroadcastRecevier(), new IntentFilter(App.TranslationActivityCancledIntentFilter));
        registerReceiver(new TranslationActivityIsTranslatingBroadcastRecevier(), new IntentFilter(App.TranslationActivityIsTranslatingIntentFilter));
        registerReceiver(new TranslationActivityHasFailedBroadcastRecevier(), new IntentFilter(App.TranslationActivityHasFailedIntentFilter));
        registerReceiver(new TranslationActivityIsShowingBroadcastRecevier(), new IntentFilter(App.TranslationActivityIsShowingResultsIntentFilter));

        return START_STICKY;
    }*/
   private HoverView hoverView;
   private volatile boolean isTranslation;
   private synchronized boolean getIsTranslation(){
       return isTranslation;
   }
    private synchronized void setIsTranslation(boolean value){
         isTranslation=value;
    }
   private LottieAnimationView mLottieAnimationView;
   private ImageView transImageView;
    private boolean isScreenRecorderInit;
    private Handler mainHander;
    @Override
    protected void onHoverMenuLaunched(@NonNull Intent intent, @NonNull HoverView hoverView) {
        // Configure and start your HoverView.
        mainHander = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                mHandler = new Handler();
                Looper.loop();
            }
        }).start();
        registerReceiver(new TranslationActivityCancledBroadcastRecevier(), new IntentFilter(App.TranslationActivityCancledIntentFilter));
        registerReceiver(new TranslationActivityIsTranslatingBroadcastRecevier(), new IntentFilter(App.TranslationActivityIsTranslatingIntentFilter));
        registerReceiver(new TranslationActivityHasFailedBroadcastRecevier(), new IntentFilter(App.TranslationActivityHasFailedIntentFilter));
        registerReceiver(new TranslationActivityIsShowingBroadcastRecevier(), new IntentFilter(App.TranslationActivityIsShowingResultsIntentFilter));
        registerReceiver(new TurnedOffBroadcastRecevier(), new IntentFilter(App.TurnedOff));
        registerReceiver(new TurnedOnBroadcastRecevier(), new IntentFilter(App.TurnedOn));

        this.hoverView = hoverView;
        initMenus();
 }
 private void initMenus(){


     HoverMenu menu =new SingleSectionHoverMenu(getApplicationContext());
     hoverView.setMenu(menu);
     hoverView.collapse();
     hoverView.setListener(new HoverViewStateCollapsed.Listener() {
         @Override
         public void onCollapsing() {

         }

         @Override
         public void onCollapsed() {

         }

         @Override
         public void onDragStart() {

         }

         @Override
         public void onDragEnd() {

         }

         @Override
         public void onDocked() {

         }

         @Override
         public void onTap() {
             if(getIsTranslation()){
                 transImageView.setVisibility(View.VISIBLE);
                 mLottieAnimationView.setVisibility(View.INVISIBLE);
                 setIsTranslation(!isTranslation);
             }
             else{
                 transImageView.setVisibility(View.INVISIBLE);
                 mLottieAnimationView.setVisibility(View.VISIBLE);
                 setIsRunning(false);
                 setIsTranslation(!isTranslation);
                 startProjection();
             }
             // Toast.makeText(getApplicationContext(),"Menu clicked",Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onExited() {

         }
     });

 }

    public class SingleSectionHoverMenu extends HoverMenu {

        private Context mContext;
        private Section mSection;

        private SingleSectionHoverMenu(@NonNull Context context) {
            mContext = context;

            mSection = new Section(
                    new SectionId("1"),
                    createTabView(),
                    createScreen()
            );
        }

        private View createTabView() {
            int padding =Utils.convertDpToPixelInt(mContext,8);
            FrameLayout frameLayout = new FrameLayout(mContext);
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(Utils.convertDpToPixelInt(mContext,72)
            ,Utils.convertDpToPixelInt(mContext,72));
            params.gravity = Gravity.CENTER;
            Drawable bg = ContextCompat.getDrawable(mContext,R.drawable.tab_background);
            //bg.setColorFilter(new PorterDuffColorFilter(Color.parseColor("#fafafa"), PorterDuff.Mode.SRC_IN));
            frameLayout.setBackground(bg);
            frameLayout.setElevation(Utils.convertDpToPixel(mContext,4));
            frameLayout.setTranslationZ(Utils.convertDpToPixel(mContext,4));

            ImageView imageView = new ImageView(mContext);
            imageView.setImageResource(R.drawable.tab_background);
            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            imageView.setColorFilter(Color.parseColor("#fafafa"));
            imageView.setElevation(Utils.convertDpToPixel(mContext,4));
            imageView.setTranslationZ(Utils.convertDpToPixel(mContext,4));


            transImageView = new ImageView(mContext);
            transImageView.setImageDrawable(new IconicsDrawable(mContext).icon(
                    GoogleMaterial.Icon.gmd_translate
            ).sizeDp(72).color(Color.parseColor("#212121")));
            transImageView.setPadding(padding*2,padding*2,padding*2,padding*2);

            mLottieAnimationView = new LottieAnimationView(mContext);
            mLottieAnimationView.setRepeatMode(LottieDrawable.RESTART);
            mLottieAnimationView.setRepeatCount(LottieDrawable.INFINITE);
            mLottieAnimationView.setAnimation("4463-hi.json");
        //    mLottieAnimationView.setPadding(padding,padding,padding,padding);
            mLottieAnimationView.playAnimation();

            mLottieAnimationView.setVisibility(View.INVISIBLE);

            //imageView.setVisibility(View.INVISIBLE);
          //  frameLayout.addView(imageView);
            frameLayout.addView(transImageView);
            frameLayout.addView(mLottieAnimationView);
            return frameLayout;
        }

        private Content createScreen() {
            return new Content() {
                /**
                 * Returns the visual display of this content.
                 *
                 * @return the visual representation of this content
                 */
                @NonNull
                @Override
                public View getView() {
                    return new View(mContext);
                }

                /**
                 * @return true to fill all available space, false to wrap content height
                 */
                @Override
                public boolean isFullscreen() {
                    return true;
                }

                /**
                 * Called when this content is displayed to the user.
                 */
                @Override
                public void onShown() {
                //   hoverView.collapse();
                }

                /**
                 * Called when this content is no longer displayed to the user.
                 * <p>
                 * Implementation Note: {@code Content} can be brought back due to user navigation so
                 * this call must not release resources that are required to show this content again.
                 */
                @Override
                public void onHidden() {

                }
            };
        }

        @Override
        public String getId() {
            return "singlesectionmenu";
        }

        @Override
        public int getSectionCount() {
            return 1;
        }

        @Nullable
        @Override
        public Section getSection(int index) {
            if (0 == index) {
                return mSection;
            } else {
                return null;
            }
        }

        @Nullable
        @Override
        public Section getSection(@NonNull SectionId sectionId) {
            if (sectionId.equals(mSection.getId())) {
                return mSection;
            } else {
                return null;
            }
        }

        @NonNull
        @Override
        public List<Section> getSections() {
            return Collections.singletonList(mSection);
        }

    }

    private class TranslationActivityCancledBroadcastRecevier  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            transImageView.setVisibility(View.VISIBLE);
            mLottieAnimationView.setVisibility(View.INVISIBLE);

            setIsTranslation(false);
            setIsRunning(false);
        }}

    private class TranslationActivityIsTranslatingBroadcastRecevier  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
        }}

    private class TurnedOffBroadcastRecevier  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            hoverView.close();
            stopProjection();
        }}

    private class TurnedOnBroadcastRecevier  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            initMenus();
        }}

    private class TranslationActivityHasFailedBroadcastRecevier  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            setIsTranslation(false);
            transImageView.setVisibility(View.VISIBLE);
            mLottieAnimationView.setVisibility(View.INVISIBLE);

            setIsRunning(false);
        }}
    private class TranslationActivityIsShowingBroadcastRecevier  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            setIsTranslation(false);
            transImageView.setVisibility(View.VISIBLE);
            mLottieAnimationView.setVisibility(View.INVISIBLE);
           //setIsRunning(false);
        }}
    private void startListener(){
   //     mDetectorThread.startDetection();
        registerReceiver(mScreenshotPermissionReceiver, new IntentFilter(App.Permission.Receiver));

    }
    protected void onScreenShotTaken(String path, String fileName) {
        startListener();
    }
    private class ScreenshotPermissionReceiver  extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            Bundle extras = intent.getExtras();
            boolean mPermissionGiven = extras.getBoolean(App.Permission.PermissionGiven);
           if(mPermissionGiven) {
               startProjection();
           }}}




    @Override
    public void onDoubleTapped() {

        App.getScreenshotPermission();

    }
    private long previousBitmapTakenTime=0;
    private Bitmap previousBitmapTaken=null;
    private Calendar c = Calendar.getInstance();
    private final long timediff = 2000;
    private  boolean isRunning = false;
    private  boolean getIsRunning(){
        return  isRunning;
    }
    private  void setIsRunning(boolean value){
        App.Log("setIsRunning "+value);
          isRunning =value;
    }
    private class ImageAvailableListener implements  ImageReader.OnImageAvailableListener {
        @Override
        public void onImageAvailable(ImageReader reader) {
            Image image = null;
            FileOutputStream fos = null;
            Bitmap bitmap = null;
            Bitmap  bitmapScaled =null;

            try {
                App.Log("onImageAvailable getIsTranslation "+getIsTranslation()+" getIsRunning "+getIsRunning());
                if(getIsTranslation()){
                image = reader.acquireLatestImage();

                if ( image != null && getIsRunning()==false) {

                    Image.Plane[] planes = image.getPlanes();
                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();
                    int rowPadding = rowStride - pixelStride * mWidth;
                    long time =c.getTimeInMillis();
                        // create bitmap
                        bitmap = Bitmap.createBitmap(mWidth + rowPadding / pixelStride, mHeight, Bitmap.Config.ARGB_8888);
                        bitmap.copyPixelsFromBuffer(buffer);
                    bitmapScaled = Bitmap.createBitmap(bitmap,0,App.StatusBarHeight
                            ,bitmap.getWidth(),bitmap.getHeight()-App.StatusBarHeight);

                          final   String path = STORE_DIRECTORY+ "/myscreen_" + org.apache.commons.lang.RandomStringUtils.randomAlphabetic(16) + ".png";
                            // write bitmap to a file
                            fos = new FileOutputStream(path);
                    bitmapScaled.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    mainHander.post(new Runnable() {
                        @Override
                        public void run() {

                            if(getIsRunning()==false){

                                setIsRunning(true);
                                App.Log("doFor isRunning "+isRunning+" path "+path);
                                Intent intent = new Intent(DoubleTabObserverService.this,TranslationActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                              //  intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                intent.putExtra(App.Path,path);
                                startActivity(intent);
                            }
                            setIsRunning(true);
                        }
                    });

                            /*Intent intent = new Intent(getBaseContext(),TranslationActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            intent.putExtra(App.Path,path);
                            startActivity(intent);*/

                         //   stopProjection();

                        IMAGES_PRODUCED++;



                }}

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException ioe) {
                        ioe.printStackTrace();
                    }
                }

                if (bitmap != null) {
                    bitmap.recycle();
                }

                if (bitmapScaled != null) {
                    bitmapScaled.recycle();
                }

                if (image != null) {
                    image.close();
                }
            }
        }
    }
   /* private class ImageAvailableListener implements  ImageReader.OnImageAvailableListener {
        @Override
        public void onImageAvailable(ImageReader reader) {
            Image image = null;
            FileOutputStream fos = null;
            Bitmap bitmap = null;

            try {
                image = reader.acquireLatestImage();
                if (isRunning &&image != null) {
                    Image.Plane[] planes = image.getPlanes();
                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();
                    int rowPadding = rowStride - pixelStride * mWidth;
                    long time =c.getTimeInMillis();
                    if(time -previousBitmapTakenTime>=timediff){
                        // create bitmap
                        bitmap = Bitmap.createBitmap(mWidth + rowPadding / pixelStride, mHeight, Bitmap.Config.ARGB_8888);
                        bitmap.copyPixelsFromBuffer(buffer);
                        if(previousBitmapTaken!=null&&bitmap.getRowBytes()==previousBitmapTaken.getRowBytes()){
                            isRunning = false;

                            String path = STORE_DIRECTORY+ "/myscreen_" + org.apache.commons.lang.RandomStringUtils.random(16) + ".png";
                            // write bitmap to a file
                            fos = new FileOutputStream(path);
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                            Intent intent = new Intent(getBaseContext(),TranslationActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            intent.putExtra(App.Path,path);
                            startActivity(intent);
                        }
                        String path = STORE_DIRECTORY+ "/myscreen_" + org.apache.commons.lang.RandomStringUtils.random(16) + ".png";
                        // write bitmap to a file
                        //fos = new FileOutputStream(path);
                        //bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        //Intent intent = new Intent(getBaseContext(),TranslationActivity.class);
                        //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        //intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        //intent.putExtra(App.Path,path);
                        //startActivity(intent);
                        //  stopProjection();
                        IMAGES_PRODUCED++;

                        previousBitmapTakenTime = time;
                        previousBitmapTaken = bitmap;
                    }

                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException ioe) {
                        ioe.printStackTrace();
                    }
                }

                if (bitmap != null) {
                    bitmap.recycle();
                }

                if (image != null) {
                    image.close();
                }
            }
        }
    }
*/
    private class OrientationChangeCallback extends OrientationEventListener {

        OrientationChangeCallback(Context context) {
            super(context);
        }

        @Override
        public void onOrientationChanged(int orientation) {
            final int rotation = mDisplay.getRotation();
            if (rotation != mRotation) {
                mRotation = rotation;
                try {
                    // clean up
                    if (mVirtualDisplay != null) mVirtualDisplay.release();
                    if (mImageReader != null) mImageReader.setOnImageAvailableListener(null, null);

                    // re-create virtual display depending on device width / height
                    createVirtualDisplay();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class MediaProjectionStopCallback extends MediaProjection.Callback {
        @Override
        public void onStop() {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (mVirtualDisplay != null) mVirtualDisplay.release();
                    if (mImageReader != null) mImageReader.setOnImageAvailableListener(null, null);
                    if (mOrientationChangeCallback != null) mOrientationChangeCallback.disable();
                    sMediaProjection.unregisterCallback(MediaProjectionStopCallback.this);
                }
            });
        }
    }
    private void startProjection(){
        if(isScreenRecorderInit){
            stopProjection();
        }
        setIsRunning(false);
            MediaProjectionManager   mediaProjectionManager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);

            sMediaProjection=mediaProjectionManager.getMediaProjection(Activity.RESULT_OK,App.getScreenshotPermissionIntent() );

            if (sMediaProjection != null) {
                STORE_DIRECTORY = getBaseContext().getFilesDir().getAbsolutePath() + "/cache/";
                File storeDirectory = new File(STORE_DIRECTORY);
                if (!storeDirectory.exists()) {
                    boolean success = storeDirectory.mkdirs();
                    if (!success) {
                        return;
                    }
                }

                // display metrics
                DisplayMetrics metrics = getResources().getDisplayMetrics();
                mDensity = metrics.densityDpi;
                mDisplay =((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();

                // create virtual display depending on device width / height
                createVirtualDisplay();

                // register orientation change callback
                mOrientationChangeCallback = new OrientationChangeCallback(this);
                if (mOrientationChangeCallback.canDetectOrientation()) {
                    mOrientationChangeCallback.enable();
                }

                // register media projection stop callback
                sMediaProjection.registerCallback(new MediaProjectionStopCallback(), mHandler);
                isScreenRecorderInit = true;
            }

    }
    private void stopProjection() {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (sMediaProjection != null) {
                    sMediaProjection.stop();
                }
            }
        });
    }

    /****************************************** Factoring Virtual Display creation ****************/
    private void createVirtualDisplay() {
        // get width and height

        DisplayMetrics metrics = new DisplayMetrics();
        Point size = new Point();
        mDisplay.getRealMetrics(metrics);
        mWidth = metrics.widthPixels;
        mHeight = metrics.heightPixels;

        // start capture reader
        mImageReader = ImageReader.newInstance(mWidth, mHeight, PixelFormat.RGBA_8888, 2);
        mVirtualDisplay = sMediaProjection.createVirtualDisplay(SCREENCAP_NAME, mWidth, mHeight, mDensity, VIRTUAL_DISPLAY_FLAGS, mImageReader.getSurface(), null, mHandler);
        mImageReader.setOnImageAvailableListener(new ImageAvailableListener(), mHandler);
    }




}
