package transearly.app.ltd.com.transearly;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mikepenz.google_material_typeface_library.GoogleMaterial;
import com.mikepenz.iconics.context.IconicsContextWrapper;

import java.util.List;

import transearly.app.ltd.com.transearly.color.MMCQ;
import transearly.app.ltd.com.transearly.data.TonduNetworkUtils;
import transearly.app.ltd.com.transearly.data.TonduResponse;
import transearly.app.ltd.com.transearly.data.TonduText;
import transearly.app.ltd.com.transearly.utils.FileUtils;

public class TranslationActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(IconicsContextWrapper.wrap(newBase));
    }
    private FrameLayout textPanel;
    private String filePath;
    private  ImageView screen_img_view;
    private View overlay;
    private Handler backendHander;
    private Bitmap bm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
       // getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                |View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);


        setContentView(R.layout.activity_translation);
         textPanel=findViewById(R.id.textPanel);
        overlay =findViewById(R.id.overlay);


        Intent intent =getIntent();
        filePath=intent.getStringExtra(App.Path);
         screen_img_view = findViewById(R.id.screen_img_view);
        bm=BitmapFactory.decodeFile(filePath);
        screen_img_view.setImageBitmap(bm);
        overlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                end();
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                backendHander = new Handler();
                Looper.loop();
            }
        }).start();
        startTranslation();
    }
    private void end(){

        textPanel.removeAllViews();
        textPanel.invalidate();
        screen_img_view.setImageDrawable(null);
        screen_img_view.invalidate();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                |View.SYSTEM_UI_FLAG_FULLSCREEN);
        Intent intent= new Intent();
        intent.setAction( App.TranslationActivityCancledIntentFilter);
        sendBroadcast(intent);
        finish();
        overridePendingTransition(0,0);
    }
    private void testS3(){
  /* App.ReadToken(this, new App.ReadTokenListener() {
         @Override
         public void TokenRead(String token) {

             try{
                 String response=   TonduNetworkUtils.RequestS3Url(token);
                 App.Log("testS3 response "+response);
             }
             catch (Exception e){
                 App.Log("testS3 error "+e.getMessage());
             }
         }
     });*/
    }
    private void startTranslation(){
        App.ReadToken(this, new App.ReadTokenListener() {
            @Override
            public void TokenRead(String token) {
                startTranslation( token);

            }
        });
    }
    private void startTranslation(final String token){
       final String lan = App.Settings.GetString(this,App.Settings.Language);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    final  TonduResponse response=   TonduNetworkUtils.Translate( token, filePath,lan) ;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            drawText(response);
                        }
                    });
                }
                catch (Exception e){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            Toast.makeText(TranslationActivity.this,"Translations Failed",Toast.LENGTH_SHORT).show();
                            end();
                        }
                    });
                }
            }
        }).start();
    }

    private Bitmap bitmapScaled;
    private void paintTextViews(final TonduText mTonduText,final TextView mTextView){


        bitmapScaled = Bitmap.createBitmap(bm,(int)mTonduText.getTopGeometry().getLeft(),
                (int)mTonduText.getTopGeometry().getTop()
                ,bm.getWidth()-(int)mTonduText.getTopGeometry().getLeft(),bm.getHeight()- (int)mTonduText.getTopGeometry().getTop());
        backendHander.post(new Runnable() {
            @Override
            public void run() {
                try{

              final  List<int[]> colors=    MMCQ.compute(bitmapScaled,2);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        int[] background = colors.get(0);
                        int[] foreground = colors.get(0);
                        mTextView.setBackgroundColor(Color.rgb(background[0],background[1],background[2]));
                        mTextView.setTextColor(Color.rgb(foreground[0],foreground[1],foreground[2]));
                    }
                });
                }
                catch (Exception e){}
                if (bitmapScaled != null) {
                    bitmapScaled.recycle();
                }
            }
        });
    }
    private void drawText(TonduResponse mTonduResponse){
        for (TonduText mTonduText:mTonduResponse.getBody()) {
            TextView mTextView = new TextView(this);
            if(mTonduText.getTranslatedText()!=null){
                textPanel.addView(mTextView,(int)mTonduText.getMaxWidth(),(int)mTonduText.getHeight());
                mTextView.setY(mTonduText.getTopGeometry().getTop());
                mTextView.setX(mTonduText.getTopGeometry().getLeft());
                mTextView.setBackgroundColor(mTonduText.getColorFormatted());
                mTextView.setTextColor(mTonduText.getTextcolorFormatted());
                TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                        mTextView,1,100,1, TypedValue.COMPLEX_UNIT_DIP
                );

                mTextView.setText(mTonduText.getTranslatedText());
            }
        }

        Intent intent= new Intent();
        intent.setAction( App.TranslationActivityIsShowingResultsIntentFilter);
        sendBroadcast(intent);

    }

    /**
     * Take care of popping the fragment back stack or finishing the activity
     * as appropriate.
     */

    /**
     * Dispatch onPause() to fragments.
     */

    private void startTrsnation(){
        Intent intent= new Intent();
        intent.setAction( App.TranslationActivityIsTranslatingIntentFilter);

        sendBroadcast(intent);
    }
}
