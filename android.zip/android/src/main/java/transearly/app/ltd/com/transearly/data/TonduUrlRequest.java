package transearly.app.ltd.com.transearly.data;

import transearly.app.ltd.com.transearly.App;

/**
 * Created by pc on 3/30/2019.
 */

public class TonduUrlRequest extends TonduContent {

    private String Key;
    private String Language;

    public TonduUrlRequest(){}
    public TonduUrlRequest(String authorizationToken,String Key,String Language){
        super(authorizationToken, App.GeneratePublicS3UrlmethodArn);
        this.Key = Key;
        this.Language = Language;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }

    public String getLanguage() {
        return Language;
    }

    public void setLanguage(String language) {
        Language = language;
    }
}
