package transearly.app.ltd.com.transearly.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.StreamCorruptedException;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;



public class FileUtils {

	private static String[] videos_for_web= new String[]{".mp4",".3gp",".ogv",".wmv",".m4v",".mkv",".flv",".mpg",".avi"};
	private static String[] audio_for_web= new String[]{".mp3",".wav",".aac"};
	private static String[] videos= new String[]{".mp4",".3gp",".ogv",".wmv",".m4v",".mkv",".flv",".mpg",".mov",".avi",".webm"};
	private static String[] audio= new String[]{".mp3",".wav",".m4a",".m4p",".aac",".mid",".arm",".flac"};
	private static String[] docs= new String[]{".doc",".docx",".xlsx",".xls",".pdf",".epub",".ppt",".pptx"};
	private static String[] imgs= new String[]{".jpeg",".jpg",".png",".jpe",".bmp",  ".JPEG",".JPG",".PNG",".JPE",".BMP",".gif"};
	private static String[] compressed= new String[]{".zip",".rar",".ZIP",".RAR",".tar.gz",".tar",".7z" ,".gzip"};
	private static String[] app= new String[]{".apk",".ios",".exe"};
	private static String[] codeExtentions= new String[]{".java",".js",".py",".c",".cpp",".css",".xml",".fs",".lua",".pl",".h",".less",".jade",".swift",".lsp",".m",".rb",".coffee",".actionscript",".fla",".class",".json",".prop"
	};
	private static String[] webPageExtentions= new String[]{".htm",".mhtm",".html",".mhtml"};
	private static String[] textExtentions=new String[]{".txt",".md",".csv",".log"
	};
	
	public static final String TYPE_VIDEO="Videos",TYPE_AUDIO="Audios",TYPE_CODE="Code",TYPE_TEXT="Text",TYPE_DOCUMENT="Document",TYPE_IMAGE="Images",TYPE_COMPRESSED="Archives",TYPE_APPLICATION="Apps",TYPE_DIRECTORY="DIRCTORY",TYPE_UNKONWN="Others";
	
	 public static String getExtention(String fileName){
			String returnName="";
			if(fileName.contains(".")){
			String[] file=fileName.split("\\."); 
			return file[file.length-1];	
			}
			
			
			return returnName;
		}
    public static File AssetToFile(Context c,String assetName){
    	AssetManager am = c.getAssets();
    	InputStream inputStream;
		try {
			inputStream = am.open(assetName);

	    	File file = createFileFromInputStream( c, assetName,inputStream);

	        return file;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     return null;
    }
    private static File  createFileFromInputStream(Context c,String fileName,InputStream inputStream) {

      try{
                        File f = new File(c.getCacheDir(),fileName);
      OutputStream outputStream = new FileOutputStream(f);
      byte buffer[] = new byte[1024];
      int length = 0;

      while((length=inputStream.read(buffer)) > 0) {
        outputStream.write(buffer,0,length);
      }

      outputStream.close();
      inputStream.close();

      return f;
      }catch (IOException e) {
         //Logging exception
      }

      return null;
     }
	public static Bitmap getBitmapFromAsset(Context context, String filePath) {
		AssetManager assetManager = context.getAssets();

		InputStream istr;
		Bitmap bitmap = null;
		try {
			istr = assetManager.open(filePath);
			bitmap = BitmapFactory.decodeStream(istr);
		} catch (IOException e) {
			// handle exception
		}

		return bitmap;
	}
	 public static String getVideoThumb(Activity activity,String name,String path){
		 	File parent = new File(activity.getExternalCacheDir()+"/"+"videothums");
		 	if(!parent.exists()){
		 		parent.mkdirs();
		 	}
		 	File file = new File(parent,name);
		 	if(file.exists()){
		 		return file.getAbsolutePath();
		 	}
		 	else{
		 	
						try {
							
				       Bitmap result =ThumbnailUtils.createVideoThumbnail(path, MediaStore.Video.Thumbnails.FULL_SCREEN_KIND);
				       FileOutputStream stream;
							stream = new FileOutputStream(file);
							
				     if(result!=null&&result.compress(Bitmap.CompressFormat.JPEG, 100, stream)){
				    		     
							stream.flush();
							  stream.close();
						
				     
				       return file.getAbsolutePath();
				     }
				     else{stream.flush();
				     stream.close();
							
		 			     file.createNewFile();
		 			    
				     }
			
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
		 	} 
		 	return file.getAbsolutePath();
		 }
	 public static String getFileNameNoExtention(String fileName){
			String returnName="";
			if(fileName.contains(".")){
			String[] file=fileName.split("\\."); 
			String name="";
			for(int i=0;i<file.length-1;i++){
				name+=file[i];
			}
			return name;	
			}
			
			
			return returnName;
		}
	    public static void saveBytes(byte[] bytes, String destinationFile) throws IOException {
			OutputStream os = new FileOutputStream(destinationFile);
			os.write(bytes, 0, bytes.length);
			os.close();
		}
	public static void writeObjectToTemp(Object ob,File file){
		try {
			ObjectOutputStream os =new ObjectOutputStream(new FileOutputStream(file));
			os.writeObject(ob);
			os.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static Object readObjectFromTemp(File file){
		ObjectInputStream os = null;
		try {
			 os = new ObjectInputStream(new FileInputStream(file));
		} catch (StreamCorruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			return os.readObject();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} 
		
	}
	public static File getInternalStoragePath(){
		File parent=Environment.getExternalStorageDirectory().getParentFile();
		File external=Environment.getExternalStorageDirectory();
		File[] files =parent.listFiles();
		File internal=null;
		if(files!=null){
		for(int i=0;i<files.length;i++){
			if(files[i].getName().toLowerCase().startsWith("sdcard")&&!files[i].equals(external)){
				internal=files[i];
			}
		}	
		}
		
		return internal;
	}
	public static File getExtenerStoragePath(){
		
		return Environment.getExternalStorageDirectory();
	}
	
	public static String getInternalStoragePathString(){
		File parent=Environment.getExternalStorageDirectory().getParentFile();
		File external=Environment.getExternalStorageDirectory();
		File[] files =parent.listFiles();
		File internal=null;
		if(files!=null){
		for(int i=0;i<files.length;i++){
			if(files[i].getName().toLowerCase().startsWith("sdcard")&&!files[i].equals(external)){
				internal=files[i];
			}
		}	
		}
		if(internal!=null){
			return internal.getAbsolutePath();	
		}
	
		return null;
	}
	public static String getExtenerStoragePathString(){
		if(Environment.getExternalStorageDirectory()!=null){
			return Environment.getExternalStorageDirectory().getAbsolutePath();
		}
		return null;
		
	}
	public static String getDocumentsPath(){
		File parent = new File(Environment.getDownloadCacheDirectory()+"/"+"Documents");
	 	if(!parent.exists()){
	 		parent.mkdirs();
	 	}
	 	return parent.getAbsolutePath();
	}
	public static String getCacheThumPath(Context activity){
		File parent = new File(activity.getExternalCacheDir()+"/"+"thumbs");
	 	if(!parent.exists()){
	 		parent.mkdirs();
	 	}
	 	return parent.getAbsolutePath();
	}
	public static String getMimeTypeFile(String filePath){
		 String mime= MimeTypeMap.getSingleton().getMimeTypeFromExtension(getMime(filePath));
		 return mime;

	 }
	 public static String getMime(String fileName){
			String returnName="";
			if(fileName.contains(".")){
			String[] file=fileName.split("\\."); 
			return file[file.length-1];	
			}
			
			
			return returnName;
		}
	 public static String getNameFromURL(String  name){
		 String type=FileUtils.TYPE_UNKONWN;
		 if(name.contains("/")){
			String file=name.split("/")[name.split("/").length-1].toLowerCase(); 
		return file;
		 }
		 return name;
	}
	 public static String getTypeFromURL(String  name){
		 String type=FileUtils.TYPE_UNKONWN;
		if(name!=null){
			for(int i=0;i<videos_for_web.length;i++){
				 if(name.contains(videos_for_web[i].substring(1, videos_for_web[i].length()))){
					 type=FileUtils.TYPE_VIDEO;
					 break;
				 }
			 }
			 for(int i=0;i<audio_for_web.length;i++){
				 if(name.contains(audio_for_web[i].substring(1, audio_for_web[i].length()))){
					 type=FileUtils.TYPE_AUDIO;
					 break;
				 }
			 }
			 for(int i=0;i<docs.length;i++){
				 if(name.contains(docs[i].substring(1, docs[i].length()))){
					 type=FileUtils.TYPE_DOCUMENT;
					 break;
				 }
			 }
		
			 
			 for(int i=0;i<compressed.length;i++){
				 if(name.contains(compressed[i].substring(1, compressed[i].length()))){
					 type=FileUtils.TYPE_COMPRESSED;
					 break;
				 }
			 }
			 for(int i=0;i<app.length;i++){
				 if(name.contains(app[i].substring(1, app[i].length()))){
					 type=FileUtils.TYPE_APPLICATION;
					 break;
				 }
			 }
		}
			 
			
		 
		 return type;
	}
	 public static String getExtentionFromURL(String  name){
		 String type=FileUtils.TYPE_UNKONWN;
		 if(name.contains("/")){
			String file=name.split("/")[name.split("/").length-1].toLowerCase(); 
		
			 for(int i=0;i<videos_for_web.length;i++){
				 if(file.contains(videos_for_web[i])){
					 type=FileUtils.TYPE_VIDEO;
					 return videos_for_web[i];
				 }
			 }
			 for(int i=0;i<audio_for_web.length;i++){
				 if(file.contains(audio_for_web[i])){
					 return audio_for_web[i];
				 }
			 }
			 for(int i=0;i<docs.length;i++){
				 if(file.contains(docs[i])){
					 type=FileUtils.TYPE_DOCUMENT;
					 return docs[i];
				 }
			 }
		
			 
			 for(int i=0;i<compressed.length;i++){
				 if(file.contains(compressed[i])){
					 type=FileUtils.TYPE_COMPRESSED;
					 return compressed[i];
				 }
			 }
			 for(int i=0;i<app.length;i++){
				 if(file.contains(app[i])){
					 type=FileUtils.TYPE_APPLICATION;
					 return app[i];
				 }
			 }
			
		 }
		 return "";
	}
	public static String getTypeFromFile(String  name){
		 String type=FileUtils.TYPE_UNKONWN;
		 if(name.contains(".")){
			String file="."+name.split("\\.")[name.split("\\.").length-1].toLowerCase(); 
		
			 for(int i=0;i<videos.length;i++){
				 if(file.endsWith(videos[i])){
					 type=FileUtils.TYPE_VIDEO;
					 break;
				 }
			 }
			 for(int i=0;i<audio.length;i++){
				 if(file.endsWith(audio[i])){
					 type=FileUtils.TYPE_AUDIO;
					 break;
				 }
			 }
			 for(int i=0;i<docs.length;i++){
				 if(file.endsWith(docs[i])){
					 type=FileUtils.TYPE_DOCUMENT;
					 break;
				 }
			 }
			 for(int i=0;i<imgs.length;i++){
				 if(file.endsWith(imgs[i])){
					 type=FileUtils.TYPE_IMAGE;
					 break;
				 }
			 }
			 for(int i=0;i<codeExtentions.length;i++){
				 if(file.endsWith(codeExtentions[i])){
					 type=FileUtils.TYPE_CODE;
					 break;
				 }
			 }
			 for(int i=0;i<textExtentions.length;i++){
				 if(file.endsWith(textExtentions[i])){
					 type=FileUtils.TYPE_TEXT;
					 break;
				 }
			 }
			 for(int i=0;i<compressed.length;i++){
				 if(file.endsWith(compressed[i])){
					 type=FileUtils.TYPE_COMPRESSED;
					 break;
				 }
			 }
			 for(int i=0;i<app.length;i++){
				 if(file.endsWith(app[i])){
					 type=FileUtils.TYPE_APPLICATION;
					 break;
				 }
			 }
			
		 }
		 return type;
	}
	
	
}
