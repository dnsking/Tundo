package transearly.app.ltd.com.transearly.utils;

import java.io.File;
import java.util.List;

import android.Manifest.permission;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

public class SystemUtils {
	public static String CHROME_PAGAKAGE="";
	private static String tag="com.niza.siwale.apputils.SystemUtils";
	private static String[] excludeActivities=new String[]{"com.android.systemui.usb.UsbStorageActivity"};
	public static String getForegroundApplication(Context context){
		ActivityManager am=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
		RunningTaskInfo foreground=am.getRunningTasks(1).get(0);
		return foreground.topActivity.getPackageName();
	}
	public static boolean canOpenMime(Context context,String mimeType,String path,String packageName){
		boolean canOpenMime=false;
		PackageInfo packageInfo=getPackageInfo( context, packageName,PackageManager.GET_ACTIVITIES);
		Intent intent= new Intent(Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(new File(path)),mimeType);
	if(packageInfo!=null){
	
			ActivityInfo[] activities = packageInfo.activities;
			List<ResolveInfo>	intentActivities = context.getPackageManager().queryIntentActivities(intent, 0);
			if(intentActivities!=null){
			
			for(int i=0;i<activities.length;i++){
				for(int y=0;y<intentActivities.size();y++){	
					if(intentActivities.get(y).activityInfo.name.equals(activities[i].name)){
						return true;
					}
				}
			}
			}
		
			
		}
	return canOpenMime;
	}
	public static String getRunningTask(Context context,String type,String path){
		
		ActivityManager am=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> task=am.getRunningAppProcesses();
		for(int i=0;i<task.size();i++){
			if(type.equals(FileUtils.TYPE_AUDIO)){
				
				if(hasPermission(context,task.get(i).processName,permission.READ_EXTERNAL_STORAGE)&&hasPermission(context,task.get(i).processName,permission.MODIFY_AUDIO_SETTINGS)&&hasServicesRunning(context,task.get(i).processName)){
					
					if(canOpenMime( context,"audio/*",path,task.get(i).processName)||canOpenMime( context,"music/*",path,task.get(i).processName)){
						return	task.get(i).processName;
					}
				}
			}
			else{
				if(task.get(i).importance== RunningAppProcessInfo.IMPORTANCE_FOREGROUND&&hasPermission(context,task.get(i).processName,permission.READ_EXTERNAL_STORAGE)&&isActivity( context,task.get(i).processName)){
			if(isSystemPackage(getPackageInfo( context,task.get(i).processName,0))){
				if(hasPermission(context,task.get(i).processName,permission.MODIFY_AUDIO_SETTINGS))
				return	task.get(i).processName;
			}
			else{
					return	task.get(i).processName;
			}
			
			}
			}
			
				
		}
     	return	null;
	}
	public static String getRunningTask(Context context){
		
		ActivityManager am=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> task=am.getRunningAppProcesses();
		for(int i=0;i<task.size();i++){
			
				if(task.get(i).importance== RunningAppProcessInfo.IMPORTANCE_FOREGROUND&&hasPermission(context,task.get(i).processName,permission.READ_EXTERNAL_STORAGE)&&isActivity( context,task.get(i).processName)){
			if(isSystemPackage(getPackageInfo( context,task.get(i).processName,0))){
				if(hasPermission(context,task.get(i).processName,permission.MODIFY_AUDIO_SETTINGS))
				return	task.get(i).processName;
			}
			else{
					return	task.get(i).processName;
			}
			
			}
			
			
				
		}
     	return	null;
	}
	public static PackageInfo getPackageInfo(Context context,String packageName,int flag){
		PackageManager pkgmg=context.getApplicationContext().getPackageManager();
		try {
			return pkgmg.getPackageInfo(packageName, flag);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		return null;
	}
	public static String[] getPackagePermissions(PackageInfo pkgInfo){
		if(pkgInfo!=null){
			return pkgInfo.requestedPermissions;
		}
		else{
			return new String[]{};
		}
	}
	public static String getPackageName(Context context,String packageName){
		PackageInfo packageInfo=getPackageInfo( context, packageName,0);
		if(packageInfo!=null){
			return packageInfo.packageName;
		}
		else{
			return packageName;
		}
	}
	public static boolean hasPermission(Context context,String packageName,String permission){
		String[] permissions=getPackagePermissions(getPackageInfo( context, packageName,PackageManager.GET_PERMISSIONS));
		if(permissions!=null){
			for(int i=0;i<permissions.length;i++){
			if(permissions[i].equals(permission)){
				return true;
			}
		}
		}
		
		return false;
		
	}
	public static boolean isSystemPackage(PackageInfo pkgInfo){
		if(pkgInfo!=null){
			return (pkgInfo.applicationInfo.flags&ApplicationInfo.FLAG_SYSTEM)!=0;
		}
		return true;
		
	}
	public static boolean isActivity(Context context,String packageName){
		PackageInfo packageInfo=getPackageInfo( context, packageName,PackageManager.GET_ACTIVITIES);
		if(packageInfo!=null){
			ActivityInfo[] activities=packageInfo.activities;
			if(activities!=null){
				for(int i=0;i<activities.length;i++){
					if(activities[i].flags==ActivityInfo.FLAG_EXCLUDE_FROM_RECENTS
							||activities[i].flags==ActivityInfo.FLAG_NO_HISTORY
							||activities[i].flags==ActivityInfo.FLAG_AUTO_REMOVE_FROM_RECENTS
							||activities[i].flags==ActivityInfo.FLAG_FINISH_ON_TASK_LAUNCH){
						return false;
					}
			}
			}
			
		return activities!=null;
		}
		return false;
		
		
	}
	public static boolean hasServicesRunning(Context context,String packageName){
		PackageInfo packageInfo=getPackageInfo( context, packageName,PackageManager.GET_SERVICES);
		
		if(packageInfo!=null){
			ServiceInfo[] services=packageInfo.services;
			if(services!=null){
				for(int i=0;i<services.length;i++){
					if(isServiceRunning( context,services[i].name)){
						return true;
					}
					
				}
			}
		}
		return false;
		
		
	}
	private static boolean hasLollipop(){
		return Build.VERSION.SDK_INT>=21;
	}
	public static boolean isConnectionAvaliable(Context context){
	    ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo netInfo=cm.getActiveNetworkInfo();
	    	return netInfo!=null&&netInfo.isConnected();
	   
	}
	public static boolean isWifiReachable(Context context) {
		 ConnectivityManager mManager =
		 (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
		 NetworkInfo current = mManager.getActiveNetworkInfo();
		 if(current == null) {
		 return false;
		 }
		 return (current.getType() == ConnectivityManager.TYPE_WIFI);
		 }
	 public static boolean isConnected(Context context) {
		 ConnectivityManager mManager =
		 (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
		 NetworkInfo current = mManager.getActiveNetworkInfo();
		 if(current == null) {
		 return isWifiReachable(context);
		 }
		 else return (current.isConnected());
		
		 }
	public static boolean isServiceRunning(Context context,Class<?> serviceClass){
		ActivityManager am=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
		for(RunningServiceInfo service:am.getRunningServices(Integer.MAX_VALUE)){
			if(serviceClass.getName().equals(service.service.getClassName())){
				return true;
			}
		}
		return false;
	}
	public static boolean isServiceRunning(Context context,String serviceName){
		ActivityManager am=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
		for(RunningServiceInfo service:am.getRunningServices(Integer.MAX_VALUE)){
			
			if(serviceName.equals(service.service.getClassName())){
				return true;
			}
		}
		return false;
	}
	

}
