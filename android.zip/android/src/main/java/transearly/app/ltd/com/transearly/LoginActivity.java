package transearly.app.ltd.com.transearly;

import android.app.PendingIntent;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.okta.appauth.android.OktaAppAuth;

import net.openid.appauth.AuthorizationException;

import java.util.Calendar;

public class LoginActivity extends AppCompatActivity {

    private Button mGetstartBtn;
    private OktaAppAuth mOktaAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

         mOktaAuth = OktaAppAuth.getInstance(this);
        //
        // Do any of your own setup of the Activity
        setContentView(R.layout.activity_login);
       // mGetstartBtn = findViewById(R.id.getstartBtn);

        init();
    }
    private void refreshAccessToken() {
    }
    private void init(){
        mOktaAuth.init(
                this,
                new OktaAppAuth.OktaAuthListener() {
                    @Override
                    public void onSuccess() {
                        //   onSuccess();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                if(mOktaAuth.isUserLoggedIn()){
                                    Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    startActivity(intent);
                                    finish();}
                                else{
                                    new android.os.CountDownTimer(2000,2000){
                                        @Override
                                        public void onTick(long l) {
                                        }

                                        @Override
                                        public void onFinish() {
                                            loginuser();

                                        }
                                    }.start();
                                   // onSuccess();
                                }
                            }
                        });
                    }

                    @Override
                    public void onTokenFailure(@NonNull AuthorizationException ex) {
                        // Handle a failed initialization
                        App.Log("onTokenFailure "+ex.toString());
                      //  init();
                    }
                }
        );
    }
    public void loginuser() {
        // Handle a successful initialization (e.g. display login button)

        Intent completionIntent = new Intent(this, MainActivity.class);
        Intent cancelIntent = new Intent(this, LoginActivity.class);
        cancelIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        mOktaAuth.login(
                this,
                PendingIntent.getActivity(this, 0, completionIntent, 0),
                PendingIntent.getActivity(this, 0, cancelIntent, 0)
        );
    }

    @Override
    protected void onDestroy() {
        if (mOktaAuth != null) {
            mOktaAuth.dispose();
            mOktaAuth = null;
        }
        super.onDestroy();
    }
}
