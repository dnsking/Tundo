package transearly.app.ltd.com.transearly.data;

public class Geometry {
	private float Height;
	private float Left;
	private float Top;
	private float Width;

	public float getHeight() {
		return Height;
	}

	public void setHeight(float height) {
		Height = height;
	}

	public float getLeft() {
		return Left;
	}

	public void setLeft(float left) {
		Left = left;
	}

	public float getTop() {
		return Top;
	}

	public void setTop(float top) {
		Top = top;
	}

	public float getWidth() {
		return Width;
	}

	public void setWidth(float width) {
		Width = width;
	}
}
