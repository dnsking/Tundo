package transearly.app.ltd.com.transearly.recorder;

import android.content.Context;
import android.media.AudioRecord;
import android.provider.MediaStore;

import com.musicg.fingerprint.FingerprintSimilarity;
import com.musicg.wave.Wave;
import com.musicg.wave.WaveHeader;

import java.io.FileNotFoundException;
import java.io.IOException;


/**
 * Created by pc on 7/19/2018.
 */

public class AudioFingerPrinter {
    private Context mContext;
    private Wave mainWave;
    private WaveHeader waveHeader;
    public AudioFingerPrinter(Context mContext, AudioRecord audioRecord) throws IOException {
        this.mContext = mContext;
        mainWave = new Wave(mContext.getAssets().open("tap.wav"));
        waveHeader = new WaveHeader();
        waveHeader.setChannels(1);
        waveHeader.setBitsPerSample(16);
        waveHeader.setSampleRate(audioRecord.getSampleRate());
    }
    public FingerprintSimilarity getSimilarities(byte[] audioBytes){

       return mainWave.getFingerprintSimilarity(new Wave(waveHeader, audioBytes));
    }
}
