package transearly.app.ltd.com.transearly.data;

/**
 * Created by pc on 3/30/2019.
 */

public class TonduS3UrlReponse {
    private String statusCode;
    private String body;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
