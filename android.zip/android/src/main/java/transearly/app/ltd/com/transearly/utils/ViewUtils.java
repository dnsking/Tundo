package transearly.app.ltd.com.transearly.utils;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.graphics.Palette;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Calendar;


public class ViewUtils {
	public static interface OnSnapShootCompleteListener {
		
		 void onComplete(Bitmap bitmap);
	}
	public static void styleViewFromPallet(final Bitmap bm,final  View view, final TextView... mTextViews ){
	    new Palette.Builder(bm).generate(new Palette.PaletteAsyncListener() {
            @Override
            public void onGenerated(@NonNull Palette palette) {
             int bgColor=   palette.getDarkVibrantColor(Color.parseColor("#555466"));
                view.setBackgroundColor(bgColor);
            }
        });
    }
	public static void addCircularBackground(int color,View view){

		ShapeDrawable	circle = new ShapeDrawable(new OvalShape());
		circle.clearColorFilter();
		circle.getPaint().setAntiAlias(true);
		circle.getPaint().setColor(color);
		
		view.setBackground(circle);
	}
    public static  void drawCircle(View view,int color,ShapeDrawable circle ){
		
		circle.clearColorFilter();
		circle.getPaint().setAntiAlias(true);
		circle.getPaint().setColor(color);
		
			circle.getPaint().setStyle(Paint.Style.FILL);
		
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN){
			view.setBackground(circle);
		}
		else{
			view.setBackgroundDrawable(circle);
		}
	}  
    public static ProgressDialog showProgressDialog(Activity context, String message) {
        ProgressDialog mDialog = new ProgressDialog(context);
        mDialog.setCancelable(false);
        mDialog.setMessage(message);
        mDialog.setIndeterminate(true);
        mDialog.show();
        return mDialog;
    }
    
    public static void makeLinksClickable(final EditText ediText){
    	ediText.setLinksClickable(true);
    	ediText.setAutoLinkMask(Linkify.WEB_URLS);
    	ediText.setMovementMethod(LinkMovementMethod.getInstance());
    	Linkify.addLinks(ediText, Linkify.WEB_URLS);
    	ediText.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub
				Linkify.addLinks(ediText, Linkify.WEB_URLS);
			}});
    }
    public static void AddGradientBackground(View layout,int color0,int color1){
		GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{color0,color1});
		gd.setCornerRadius(0);
		layout.setBackgroundDrawable(gd);
	}
    public static void getViewSnapShoothootBackground(final View view,final OnSnapShootCompleteListener onSnapShootCompleteListener){
		Thread t=new Thread(new Runnable(){

			@Override
			public void run() {
				getViewSnapShoothoot(view,onSnapShootCompleteListener);
			}});
    	t.setPriority(Thread.MIN_PRIORITY);
    	t.start();
    }
    public static Bitmap ViewToBitmap(View view){
    	view.measure(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
    	Bitmap bm = Bitmap.createBitmap(view.getMinimumWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
    	Canvas c = new Canvas(bm);
    	view.layout(0, 0,view.getMinimumWidth(), view.getMeasuredHeight());
    	view.draw(c);
    	return bm;
    }
    public static Bitmap getViewSnapShoothoot(final View view,final OnSnapShootCompleteListener onSnapShootCompleteListener){
    	
				view.setDrawingCacheEnabled(true);
				Bitmap bm= Bitmap.createBitmap(view.getDrawingCache());
				
			   	 if(onSnapShootCompleteListener!=null)
			   	onSnapShootCompleteListener.onComplete(bm);
			   	return bm;
			
    }

	public static void SaveBitmap(Bitmap bm,String path){
		try {
			bm.compress(Bitmap.CompressFormat.JPEG, 100, new FileOutputStream(new File(path)));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String generateTempFolder(Context activity){
		Calendar c = Calendar.getInstance();

		File parent = new File(activity.getExternalCacheDir()+"/Temp/"+c.getTimeInMillis());
		if(!parent.exists()){
			parent.mkdirs();
		}
		return parent.getAbsolutePath();
	}

	public static String generateTempVideosFolder(Context activity){

		File parent = new File(activity.getExternalCacheDir()+"/Video");
		if(!parent.exists()){
			parent.mkdirs();
		}
		return parent.getAbsolutePath();
	}
}
