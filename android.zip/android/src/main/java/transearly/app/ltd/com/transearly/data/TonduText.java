package transearly.app.ltd.com.transearly.data;

import android.graphics.Color;

import java.util.regex.Pattern;

import transearly.app.ltd.com.transearly.App;

/**
 * Created by pc on 3/31/2019.
 */

public class TonduText {

    private String Text;
    private Geometry TopGeometry ;
    private Geometry BottomGeometry;
    private float Height;
    private float MaxWidth;
    private String TranslatedText;
    private String color;
    private String textcolor;

    public String getText() {
        return Text;
    }

    public void setText(String text) {
        Text = text;
    }

    public Geometry getTopGeometry() {
        return TopGeometry;
    }

    public void setTopGeometry(Geometry topGeometry) {
        TopGeometry = topGeometry;
    }

    public Geometry getBottomGeometry() {
        return BottomGeometry;
    }

    public void setBottomGeometry(Geometry bottomGeometry) {
        BottomGeometry = bottomGeometry;
    }

    public float getHeight() {
        return Height;
    }

    public void setHeight(float height) {
        Height = height;
    }

    public float getMaxWidth() {
        return MaxWidth;
    }

    public void setMaxWidth(float maxWidth) {
        MaxWidth = maxWidth;
    }

    public String getTranslatedText() {
        return TranslatedText;
    }

    public void setTranslatedText(String translatedText) {
        TranslatedText = translatedText;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTextcolor() {
        return textcolor;
    }

    public void setTextcolor(String textcolor) {
        this.textcolor = textcolor;
    }

    public int getColorFormatted() {
        if(color!=null){
            App.Log("startTranslation color "+color);
            String[] colorCode = color.substring(1,color.length()-1).split(",");
        return   Color.rgb((int)Float.parseFloat(colorCode[0]),(int)Float.parseFloat(colorCode[1]),(int)Float.parseFloat(colorCode[2])) ;
        }
        return Color.WHITE;
    }

    public int getTextcolorFormatted() {
        if(textcolor!=null){
            String[] colorCode = textcolor.substring(1,textcolor.length()-1).split(",");
           return Color.rgb((int)Float.parseFloat(colorCode[0]),(int)Float.parseFloat(colorCode[1]),(int)Float.parseFloat(colorCode[2])) ;
        }
        return Color.BLACK;
    }

}
