package transearly.app.ltd.com.transearly.views;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;

import com.ramotion.directselect.DSDefaultPickerBox;

/**
 * Created by pc on 3/31/2019.
 */

public class CustomDSDefaultPickerBox extends DSDefaultPickerBox {
    public interface OnSelectLanguageListener{
        void languageSelected(String lan,int index);
    }
    private OnSelectLanguageListener mOnSelectLanguageListener;

    public CustomDSDefaultPickerBox(@NonNull Context context) {
        super(context);
    }

    public CustomDSDefaultPickerBox(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomDSDefaultPickerBox(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void onSelect(String value, int index) {
        super.onSelect(value, index);
        if(mOnSelectLanguageListener!=null){
            mOnSelectLanguageListener.languageSelected(value,index);
        }
    }

    public OnSelectLanguageListener getOnSelectLanguageListener() {
        return mOnSelectLanguageListener;
    }

    public void setOnSelectLanguageListener(OnSelectLanguageListener mOnSelectLanguageListener) {
        this.mOnSelectLanguageListener = mOnSelectLanguageListener;
    }
}
