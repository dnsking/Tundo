package transearly.app.ltd.com.transearly;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import transearly.app.ltd.com.transearly.utils.SystemUtils;

/**
 * Created by pc on 11/6/2018.
 */

public class BootupReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent1) {
        if(!SystemUtils.isServiceRunning(context,DoubleTabObserverService.class)){
            Intent intent = new Intent(context,DoubleTabObserverService.class);
            context.startService(intent);
        }

    }
}
