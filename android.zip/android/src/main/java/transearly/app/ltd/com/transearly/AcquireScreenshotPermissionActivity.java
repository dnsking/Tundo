package transearly.app.ltd.com.transearly;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by pc on 11/6/2018.
 */

public class AcquireScreenshotPermissionActivity  extends Activity {
    private MediaProjectionManager mediaProjectionManager;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(null);
        mediaProjectionManager = (MediaProjectionManager)this.getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mediaProjectionManager.createScreenCaptureIntent(), 1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Intent intent = new Intent(App.Permission.Receiver);
        Bundle mBundle = new Bundle();
        if (1 == requestCode) {
            if (Activity.RESULT_OK == resultCode) {
                App.setScreenshotPermission((Intent) data.clone());
                mBundle.putBoolean(App.Permission.PermissionGiven,true);
                intent.putExtras(mBundle);
                sendBroadcast(intent);
            }
         else if (Activity.RESULT_CANCELED == resultCode) {
            App.setScreenshotPermission(null);

            mBundle.putBoolean(App.Permission.PermissionGiven,false);
            intent.putExtras(mBundle);
            sendBroadcast(intent);

        }}
        finish();
    }
}
