package transearly.app.ltd.com.transearly.data;

/**
 * Created by pc on 3/31/2019.
 */

public class TonduResponse {
    private String statusCode;
    private TonduText  body[];

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public TonduText[] getBody() {
        return body;
    }

    public void setBody(TonduText[] body) {
        this.body = body;
    }
}
