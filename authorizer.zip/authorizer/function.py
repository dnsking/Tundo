import os
import string
import time
import json
from okta_jwt.jwt import validate_token
from okta_jwt.jwt import generate_token

def lambda_handler(event, context):
    token = event["authorizationToken"]
    issuer = event["issuer"]
    audience = event["audience"]
    client_ids = event["client_ids"]
    try:
        claims = validate_token(token, issuer, audience, client_ids)
        principalId = claims["sub"]
        authResponse = generatePolicy(principalId, claims['sub'], 'Allow', event['methodArn'])
        print(res)
        return authResponse
    except:
        return generatePolicy(None, None, 'Deny', event['methodArn'])

def generatePolicy(principalId, name, effect, methodArn):
    authResponse = {}
    authResponse['principalId'] = principalId
 
    if effect and methodArn:
        policyDocument = {
            'Version': '2012-10-17',
            'Statement': [
                {
                    'Sid': 'FirstStatement',
                    'Action': 'execute-api:Invoke',
                    'Effect': effect,
                    'Resource': methodArn
                }
            ]
        }
 
        authResponse['policyDocument'] = policyDocument
 
        if name is not None:
            context = {
                'name': name
            }
            authResponse['context'] = context
 
    return authResponse

    
